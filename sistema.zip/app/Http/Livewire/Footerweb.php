<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Footerweb extends Component
{
    public function render()
    {
        return view('livewire.footerweb');
    }
}
