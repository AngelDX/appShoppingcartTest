<x-index-layout>
    @livewire('web.productmain')
</x-index-layout>
{{-- Se cambio a indexweb --}}
