<div>
    @livewire('web.productmain')
</div>
