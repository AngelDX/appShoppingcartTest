<footer class="bg-gray-800 text-center text-gray-200">
    {{-- <div class="px-6 pt-3">
        <div class="mb-3 flex justify-center">
            <a href="#!" class="flex items-center justify-center m-1 h-9 w-9 rounded-full border-2 border-gray-400 leading-normal text-gray-400 transition duration-150 ease-in-out hover:text-white hover:border-white focus:outline-none focus:ring-0">
                <i class="fa-brands fa-facebook-f"></i>
            </a>
            <a href="#!" class="flex items-center justify-center m-1 h-9 w-9 rounded-full border-2 border-gray-400 leading-normal text-gray-400 transition duration-150 ease-in-out hover:text-white hover:border-white focus:outline-none focus:ring-0">
                <i class="fa-brands fa-youtube"></i>
            </a>
            <a href="#!" class="flex items-center justify-center m-1 h-9 w-9 rounded-full border-2 border-gray-400 leading-normal text-gray-400 transition duration-150 ease-in-out hover:text-white hover:border-white focus:outline-none focus:ring-0">
                <i class="fa-brands fa-facebook-f"></i>
            </a>
            <a href="#!" class="flex items-center justify-center m-1 h-9 w-9 rounded-full border-2 border-gray-400 leading-normal text-gray-400 transition duration-150 ease-in-out hover:text-white hover:border-white focus:outline-none focus:ring-0">
                <i class="fa-brands fa-facebook-f"></i>
            </a>
        </div>
    </div> --}}
    <div class="p-4 text-center">
        ©2023 Copyright: JuliacaFlower
    </div>
</footer>
