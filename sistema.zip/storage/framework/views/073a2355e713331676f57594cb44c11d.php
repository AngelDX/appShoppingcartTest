<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('web.productmain')->html();
} elseif ($_instance->childHasBeenRendered('l4294373215-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4294373215-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4294373215-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4294373215-0');
} else {
    $response = \Livewire\Livewire::mount('web.productmain');
    $html = $response->html();
    $_instance->logRenderedChild('l4294373215-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH D:\LARAVEL\appShoppingcartTest\resources\views/livewire/indexweb.blade.php ENDPATH**/ ?>