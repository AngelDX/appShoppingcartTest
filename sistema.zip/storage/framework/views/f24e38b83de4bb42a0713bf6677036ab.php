<div class="py-5">
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Categorías
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4 dark:bg-gray-800/50 dark:bg-gradient-to-bl">
            productos
        </div>
    </div>
</div>
<?php /**PATH D:\LARAVEL\appShoppingcartTest\resources\views/livewire/admin/product-management.blade.php ENDPATH**/ ?>