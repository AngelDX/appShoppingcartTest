<footer class="bg-gray-800 text-center text-gray-200">
    
    <div class="p-4 text-center">
        ©2023 Copyright: JuliacaFlower
    </div>
</footer>
<?php /**PATH D:\LARAVEL\appShoppingcartTest\resources\views/livewire/footerweb.blade.php ENDPATH**/ ?>