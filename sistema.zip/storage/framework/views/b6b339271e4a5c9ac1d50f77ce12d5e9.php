<div>
    
    <div class="w-full mb-4 dark:text-gray-400">
        <div class="text-center border-b-2 border-gris-200 py-2">
            <h3 class="uppercase font-bold text-lg mb-2">Categorías</h3>
            <ul class="flex justify-center gap-4">
                <li class="hover:border-b-indigo-600 border-b-2 mb-1">
                    <input wire:model="sendCategory" type="radio" id="todo" name="category" value="0" checked class="mb-1 h-[1.125rem] w-[1.125rem] appearance-none rounded-[0.25rem] border-[0.125rem] border-solid border-neutral-300 outline-none before:pointer-events-none before:absolute before:h-[0.875rem] before:w-[0.875rem] before:scale-0 before:rounded-full before:bg-transparent before:opacity-0 before:shadow-[0px_0px_0px_13px_transparent] before:content-[''] checked:border-primary checked:bg-primary checked:before:opacity-[0.16] checked:after:absolute checked:after:-mt-px checked:after:ml-[0.25rem] checked:after:block checked:after:h-[0.8125rem] checked:after:w-[0.375rem] checked:after:rotate-45 checked:after:border-[0.125rem] checked:after:border-l-0 checked:after:border-t-0 checked:after:border-solid checked:after:border-white checked:after:bg-transparent checked:after:content-[''] hover:cursor-pointer hover:before:opacity-[0.04] hover:before:shadow-[0px_0px_0px_13px_rgba(0,0,0,0.6)] focus:shadow-none focus:transition-[border-color_0.2s] focus:before:scale-100 focus:before:opacity-[0.12] focus:before:shadow-[0px_0px_0px_13px_rgba(0,0,0,0.6)] focus:before:transition-[box-shadow_0.2s,transform_0.2s] focus:after:absolute focus:after:z-[1] focus:after:block focus:after:h-[0.875rem] focus:after:w-[0.875rem] focus:after:rounded-[0.125rem] focus:after:content-[''] checked:focus:before:scale-100 checked:focus:before:shadow-[0px_0px_0px_13px_#3b71ca] checked:focus:before:transition-[box-shadow_0.2s,transform_0.2s] checked:focus:after:-mt-px checked:focus:after:ml-[0.25rem] checked:focus:after:h-[0.8125rem] checked:focus:after:w-[0.375rem] checked:focus:after:rotate-45 checked:focus:after:rounded-none checked:focus:after:border-[0.125rem] checked:focus:after:border-l-0 checked:focus:after:border-t-0 checked:focus:after:border-solid checked:focus:after:border-white checked:focus:after:bg-transparent dark:border-neutral-600 dark:checked:border-primary dark:checked:bg-primary dark:focus:before:shadow-[0px_0px_0px_13px_rgba(255,255,255,0.4)] dark:checked:focus:before:shadow-[0px_0px_0px_13px_#3b71ca]">
                    <label for="todo" class="cursor-pointer">Todo</label>
                </li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="hover:border-b-indigo-600 hover:border-b-2 mb-1">
                    <input wire:model="sendCategory" type="radio" id="<?php echo e($category->name); ?>" name="category" value="<?php echo e($category->id); ?>" class="mb-1 h-[1.125rem] w-[1.125rem] appearance-none rounded-[0.25rem] border-[0.125rem] border-solid border-neutral-300 outline-none before:pointer-events-none before:absolute before:h-[0.875rem] before:w-[0.875rem] before:scale-0 before:rounded-full before:bg-transparent before:opacity-0 before:shadow-[0px_0px_0px_13px_transparent] before:content-[''] checked:border-primary checked:bg-primary checked:before:opacity-[0.16] checked:after:absolute checked:after:-mt-px checked:after:ml-[0.25rem] checked:after:block checked:after:h-[0.8125rem] checked:after:w-[0.375rem] checked:after:rotate-45 checked:after:border-[0.125rem] checked:after:border-l-0 checked:after:border-t-0 checked:after:border-solid checked:after:border-white checked:after:bg-transparent checked:after:content-[''] hover:cursor-pointer hover:before:opacity-[0.04] hover:before:shadow-[0px_0px_0px_13px_rgba(0,0,0,0.6)] focus:shadow-none focus:transition-[border-color_0.2s] focus:before:scale-100 focus:before:opacity-[0.12] focus:before:shadow-[0px_0px_0px_13px_rgba(0,0,0,0.6)] focus:before:transition-[box-shadow_0.2s,transform_0.2s] focus:after:absolute focus:after:z-[1] focus:after:block focus:after:h-[0.875rem] focus:after:w-[0.875rem] focus:after:rounded-[0.125rem] focus:after:content-[''] checked:focus:before:scale-100 checked:focus:before:shadow-[0px_0px_0px_13px_#3b71ca] checked:focus:before:transition-[box-shadow_0.2s,transform_0.2s] checked:focus:after:-mt-px checked:focus:after:ml-[0.25rem] checked:focus:after:h-[0.8125rem] checked:focus:after:w-[0.375rem] checked:focus:after:rotate-45 checked:focus:after:rounded-none checked:focus:after:border-[0.125rem] checked:focus:after:border-l-0 checked:focus:after:border-t-0 checked:focus:after:border-solid checked:focus:after:border-white checked:focus:after:bg-transparent dark:border-neutral-600 dark:checked:border-primary dark:checked:bg-primary dark:focus:before:shadow-[0px_0px_0px_13px_rgba(255,255,255,0.4)] dark:checked:focus:before:shadow-[0px_0px_0px_13px_#3b71ca]">
                    <label for="<?php echo e($category->name); ?>" class="cursor-pointer "><?php echo e($category->name); ?></label>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    
    <div>
        <?php if(auth()->guard()->check()): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Crear productos')): ?>
        <div class="mb-2 mr-5 relative">
            <button onclick="Livewire.emit('openModal', 'admin.product-create')" class="absolute right-2 top-[-60px] bg-indigo-600 px-4 py-2 rounded-md text-white font-semibold tracking-wide cursor-pointer" >
                <i class="fa-solid fa-plus"></i> Agregar producto
            </button>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="relative scale-100 p-6 bg-white dark:bg-gray-800/50 dark:bg-gradient-to-bl dark:text-gray-400 from-gray-700/50 via-transparent dark:ring-1 dark:ring-inset dark:ring-white/5 rounded-lg shadow-2xl shadow-gray-500/20 dark:shadow-none flex motion-safe:hover:scale-[1.01] transition-all duration-250 focus:outline focus:outline-2 focus:outline-red-500">
                <div>
                    <?php if($product->discount>0): ?>
                    <div class="absolute right-0 top-0 bg-red-600 text-white w-14 py-1 text-center rounded-tr-lg rounded-bl-lg">
                        -<?php echo e($product->discount); ?>%
                    </div>
                    <?php endif; ?>
                    <div class="grid lg:grid-cols-2 gap-4">
                        <a href="<?php echo e(route('product.show',$product)); ?>" class="w-full object-cover">
                            <img src="<?php if($product->image): ?><?php echo e(Storage::url($product->image->url)); ?><?php else: ?> img/sinfoto.png <?php endif; ?>">
                        </a>
                        <div>
                            <h2 class="text-xl font-semibold text-gray-900 dark:text-white"><?php echo e($product->name); ?></h2>
                            <h3 class="mt-2 text-gray-500 dark:text-gray-400 text-sm leading-relaxed"><?php echo e($product->fullname); ?></h3>
                            <div class="mt-4">
                                <?php if($product->discount>0): ?>
                                <p class="line-through text-sm">S/ <?php echo e($product->price); ?></p>
                                <?php endif; ?>
                                <p class="font-bold">S/ <?php echo e(number_format($product->price-(($product->discount/100)*$product->price),2)); ?></p>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                            <div class="absolute top-2 left-2">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Editar productos')): ?>
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['onclick' => 'Livewire.emit(\'openModal\',\'admin.product-create\','.e(json_encode(['product'=>$product])).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'Livewire.emit(\'openModal\',\'admin.product-create\','.e(json_encode(['product'=>$product])).')']); ?><i class="fas fa-edit"></i> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Eliminar productos')): ?>
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['wire:click' => '$emit(\'deleteItem\','.e($product->id).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$emit(\'deleteItem\','.e($product->id).')']); ?><i class="fas fa-trash"></i> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="mt-4 flex justify-between">
                        <div>
                            <ul class="flex items-center cursor-pointer">
                                <li class="mr-1">
                                    <i class="fas fa-star text-<?php echo e($rating >= 1 ? 'yellow' : 'gray'); ?>-400"></i>
                                </li>
                                <li class="mr-1">
                                    <i class="fas fa-star text-<?php echo e($rating >= 2 ? 'yellow' : 'gray'); ?>-400"></i>
                                </li>
                                <li class="mr-1">
                                    <i class="fas fa-star text-<?php echo e($rating >= 3 ? 'yellow' : 'gray'); ?>-400"></i>
                                </li>
                                <li class="mr-1">
                                    <i class="fas fa-star text-<?php echo e($rating >= 4 ? 'yellow' : 'gray'); ?>-400"></i>
                                </li>
                                <li class="mr-1r">
                                    <i class="fas fa-star text-<?php echo e($rating == 5 ? 'yellow' : 'gray'); ?>-400"></i>
                                </li>
                            </ul>
                            <p class="text-xs text-gray-400">Valoración del producto</p>
                        </div>
                        <button wire:click="agregarProducto(<?php echo e($product->id); ?>)" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-400">
                            <i class="fa-solid fa-cart-arrow-down text-yellow-400"></i> Agregar
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Productos vacios</p>
            <?php endif; ?>
        </div>
        <div class="mt-2"><?php echo e($products->links()); ?></div>
    </div>
    <!--Scripts - Sweetalert   -->
    <?php $__env->startPush('js'); ?>
    <script>
        Livewire.on('deleteItem',id=>{
          Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
              if (result.isConfirmed) {
                  Livewire.emitTo('web.productmain','delete',id);
                  Swal.fire(
                      'Deleted!',
                      'Your file has been deleted.',
                      'success'
                  )

              }
            })
        });
      </script>
      <?php $__env->stopPush(); ?>
</div>
<?php /**PATH D:\LARAVEL\appShoppingcartTest\resources\views/livewire/web/productmain.blade.php ENDPATH**/ ?>