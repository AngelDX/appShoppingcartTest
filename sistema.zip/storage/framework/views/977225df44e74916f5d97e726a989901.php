<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400">
    Name
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
                    <div class="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none
                text-secondary-400">
                                    <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
</svg>
                            </div>
        
        <input type="text" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm pl-8 pr-8" placeholder="your name" />

                    <div class="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none
                text-secondary-400">
                                    <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
</svg>
                            </div>
            </div>

    
    </div>
<?php /**PATH D:\LARAVEL\appShoppingcartTest\storage\framework\views/309e81ab0611381f17eeb20ae8cce423.blade.php ENDPATH**/ ?>