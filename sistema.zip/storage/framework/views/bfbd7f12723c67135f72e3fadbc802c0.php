<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        
         <!-- Scripts -->
         <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
         <!-- Styles -->
         <?php echo \Livewire\Livewire::styles(); ?>

         <script src="https://cdn.jsdelivr.net/npm/pace-js@latest/pace.min.js"></script>
         <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pace-js@latest/pace-theme-default.min.css">
    </head>
    <body class="font-sans antialiased bg-gray-100">
        <div class="sticky top-0 z-50">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('web.navbar')->html();
} elseif ($_instance->childHasBeenRendered('G7Wmfs0')) {
    $componentId = $_instance->getRenderedChildComponentId('G7Wmfs0');
    $componentTag = $_instance->getRenderedChildComponentTagName('G7Wmfs0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('G7Wmfs0');
} else {
    $response = \Livewire\Livewire::mount('web.navbar');
    $html = $response->html();
    $_instance->logRenderedChild('G7Wmfs0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

        <div class="sm:justify-center sm:items-center bg-dots-darker bg-center dark:bg-dots-lighter dark:bg-gray-900 selection:bg-red-500 selection:text-white">
            <div class="max-w-7xl mx-auto p-6 lg:p-8">
                <div class="mt-4">
                    <main>
                        <?php echo e($slot); ?>

                    </main>
                </div>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footerweb')->html();
} elseif ($_instance->childHasBeenRendered('skpvsNt')) {
    $componentId = $_instance->getRenderedChildComponentId('skpvsNt');
    $componentTag = $_instance->getRenderedChildComponentTagName('skpvsNt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('skpvsNt');
} else {
    $response = \Livewire\Livewire::mount('footerweb');
    $html = $response->html();
    $_instance->logRenderedChild('skpvsNt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <?php echo $__env->yieldPushContent('modals'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-ui-modal')->html();
} elseif ($_instance->childHasBeenRendered('inItRDT')) {
    $componentId = $_instance->getRenderedChildComponentId('inItRDT');
    $componentTag = $_instance->getRenderedChildComponentTagName('inItRDT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('inItRDT');
} else {
    $response = \Livewire\Livewire::mount('livewire-ui-modal');
    $html = $response->html();
    $_instance->logRenderedChild('inItRDT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php echo \Livewire\Livewire::scripts(); ?>

        <script type="text/javascript">
            Livewire.on('alert',function(message){
                Swal.fire(
                'Mensaje del sistema',
                message,
                'success'
                )
            })
        </script>
        <?php echo $__env->yieldPushContent('js'); ?>

    </body>
</html>
<?php /**PATH D:\LARAVEL\appShoppingcartTest\resources\views/layouts/index.blade.php ENDPATH**/ ?>